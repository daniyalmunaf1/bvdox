@if($data>0)
<i style="padding-right: 0px;" class="fa fa-bell"><p style="background: transparent;color:red;font-size: 75px;padding-bottom:69px;">.</p></i>
@else
<i class="fa fa-bell"></i>
@endif