<!-- meta tags and other links -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="BVdox is a Investment Website, Here you can earn unlimited Money by just investing and developing a network">
  <meta name="keywords" content="Investment,Network Marketing,Online Earnig,Earning,Marketing,Work From Home,Make Your Network,Invite,Invite Friends,BVdox,BVdox.com,bvdox,bvdox.com">
  <meta name="author" content="BVdox">

  <title>BVdox</title>
  <link rel="icon" type="image/png" href="{{asset('assets/images/favicon.png')}}" sizes="16x16">
  <!-- bootstrap 4  -->
  <link rel="stylesheet" href="{{asset('assets/css/vendor/bootstrap.min.css')}}">
  <!-- fontawesome 5  -->
  <link rel="stylesheet" href="{{asset('assets/css/all.min.css')}}">
  <!-- line-awesome webfont -->
  <link rel="stylesheet" href="{{asset('assets/css/line-awesome.min.css')}}">
  <link rel="stylesheet" href="{{asset('assets/css/vendor/animate.min.css')}}">
  <!-- slick slider css -->
  <link rel="stylesheet" href="{{asset('assets/css/vendor/slick.css')}}">
  <link rel="stylesheet" href="{{asset('assets/css/vendor/dots.css')}}">
  <!-- dashdoard main css -->
  <link rel="stylesheet" href="{{asset('assets/css/main.css')}}">
</head>
  <body>
    <div class="preloader">
      <div class="preloader-container">
        <span class="animated-preloader"></span>
      </div>
    </div>
  
    <!-- scroll-to-top start -->
    <div class="scroll-to-top">
      <span class="scroll-icon">
        <i class="fa fa-rocket" aria-hidden="true"></i>
      </span>
    </div>
    <!-- scroll-to-top end -->

  <div class="full-wh">
    <!-- STAR ANIMATION -->
    <div class="bg-animation">
      <div id='stars'></div>
      <div id='stars2'></div>
      <div id='stars3'></div>
      <div id='stars4'></div>
    </div><!-- / STAR ANIMATION -->
  </div>
  <div class="page-wrapper">

    <!-- account section start -->
    <div class="account-section bg_img" data-background="{{asset('assets/images/login.jpg')}}">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-5 col-lg-7">
            <div class="account-card">
              <div class="account-card__header bg_img overlay--one" data-background="{{asset('assets/images/bg/bg-6.jpg')}}">
                <h2 class="section-title">Edit user <span class="base--color">Details</span></h2>

              </div>
              <div class="account-card__body">
                <div class="row mb-none-30 justify-content-center">
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Deposit Wallet Balance</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-dollar-sign"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Lifetime Investment</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-dollar-sign"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Your Profit</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-wallet"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Current Package</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-cubes "></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
      
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Lifetime Withdrawal</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-cloud-download-alt"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Reward Income</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-user-friends"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Referral Earnings</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-user-friends"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
              
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Total team members</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-user-friends"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Total team investment</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-user-friends"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Team Profit Bonus</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-user-friends"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Your Ownership</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="2%">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-user-friends"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Lifetime Earnings</span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="200">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-credit-card"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                    <div class="col-xl-12 col-sm-6 mb-30">
                      <div class="d-widget d-flex flex-wrap">
                        <div class="col-8">
                          <span class="caption">Joining Date </span>
                          <div class="form-group">
                            <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="24 October 2022">
                          </div>
              
                        </div>
                        <div class="col-4">
                          <div class="icon ml-auto">
                            <i class="las la-credit-card"></i>
                          </div>
                        </div>
                      </div><!-- d-widget-two end -->
                    </div>
                  
                  </div><!-- row end -->
                  <section>
                
                    <h2 class="text-center my-4"><span class="">Add</span> <b class="base--color">History</b></h2>
                    <div class="row mt-50 overflow-x">
                        <div class="col-lg-12">
                          <div class="table-responsive--lg p-0">
                            <table class="table style--two white-space-nowrap">
                              <thead>
                                <tr>
                                  <th>Date</th>
                                  <th>Transaction ID</th>
                                  <th>Amount</th>
                                  <th>Wallet</th>
                                  <th>Details</th>
                                  <th>Post Balance</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td data-label="Date">   <div class="form-group">
                                    <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="24 October 2022">
                                  </div></td>
                                  <td data-label="Transaction ID">
                                    <span class="base--color">   <div class="form-group">
                                        <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="24 October 2022">
                                      </div></span>
                                  </td>
                                  <td data-label="Amount">
                                    <span class="text-success">   <div class="form-group">
                                        <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="24 October 2022">
                                      </div></span>
                                  </td>
                                  <td data-label="Wallet">
                                    <span class="badge base--bg">   <div class="form-group">
                                        <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="24 October 2022">
                                      </div></span>
                                  </td>
                                  <td data-label="Details">   <div class="form-group">
                                    <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="24 October 2022">
                                  </div></td>
                                  <td data-label="Post Balance">   <div class="form-group">
                                    <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="24 October 2022">
                                  </div></td>
                                </tr>

                              </tbody>
                            </table>

                            <button class="cmn-btn">Add History</button>
                          </div>
                        </div>
                      </div><!-- row end -->
                </section>
                  
<div class="container my-4 ">
<h4 for=""class="text-center">Send Notification</h4>
    <form class="mt-4">
      <div class="form-group">
        <label>Title</label>
        <input type="text" class="form-control" placeholder="E.g.Withdrawal Successful">
      </div>
      <div class="form-group">
        <label>Message</label>
        <textarea name="" id="" cols="30" rows="5" class="form-control" placeholder="E.g.Your withdrawal of 500rs has been successfully send to your account "></textarea>
      
      </div>

      <div class="mt-3">
        <a class="text-white cmn-btn" href="#">Submit</a> 
      </div>
    </form>
</div>

  
                  <section>
                
                    <div class="form-group mt-5">
                        <label for="">Edit Username</label>
                        <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="Ahsan">
                      </div>
                </section>
                  <section>
               
                  <div class="form-group">
                    <label for="">Set Profit Percentage</label>
                    <input type="text" class="form-control border" id="exampleInputPassword1" placeholder="22%">
                  </div>
                </section>
                <form class="mt-4">
                  <div class="mt-3">
              <a class="text-white cmn-btn" href="dashboard.html">Submit</a> 
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- account section end -->

  </div> <!-- page-wrapper end -->
    <!-- jQuery library -->
  <script src="{{asset('assets/js/vendor/jquery-3.5.1.min.js')}}"></script>
  <!-- bootstrap js -->
  <script src="{{asset('assets/js/vendor/bootstrap.bundle.min.js')}}"></script>
  <!-- slick slider js -->
  <script src="{{asset('assets/js/vendor/slick.min.js')}}"></script>
  <script src="{{asset('assets/js/vendor/wow.min.js')}}"></script>
  <script src="{{asset('assets/js/contact.js')}}"></script>
  <!-- dashboard custom js -->
  <script src="{{asset('assets/js/app.js')}}"></script>
  </body>
</html>